Start.
File2.

Other file.

New line: modified. HELLO.
Some other modification.

THIS BUG HAS BEEN FIXED!

THIS ANOTHER BUG HAS BEEN FIXED!

End.