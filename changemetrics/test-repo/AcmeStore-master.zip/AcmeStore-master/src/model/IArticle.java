package model;

public interface IArticle {
	
	public String getDescription();
	public void setDescription(String description);
	
	public double getPrice();
	public void setPrice(double price);
	
	public int getYear();
	public void setYear(int year);
	
	public int getQuantity();
	public void setQuantity(int quantity);

}
