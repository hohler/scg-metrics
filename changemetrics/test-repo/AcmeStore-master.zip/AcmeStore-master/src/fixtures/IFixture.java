package fixtures;

import java.util.List;

import model.IArticle;

public interface IFixture {
	public List<IArticle> getFixtures();
}
