Start.

file3 created.

File3 Bug has been fixed!

End.