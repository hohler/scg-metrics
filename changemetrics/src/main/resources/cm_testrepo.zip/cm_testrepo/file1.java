Start.
New line.

THE BUG HAS BEEN FIXED NOW!

Some other line.
Line after empty line.

//removed

Hello this is a modification

End.